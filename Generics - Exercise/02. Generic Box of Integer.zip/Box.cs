﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericBoxOfString
{
    public class Box<T>
    {
        public Box() { }
        public void ToString(T item)
        {
            Console.WriteLine($"{item.GetType()}: {item.ToString()}");
        }
    }
}
