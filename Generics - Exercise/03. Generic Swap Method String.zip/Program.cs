﻿using Swapper;

int n = int.Parse(Console.ReadLine());
List<string> list = new List<string>();
for(int i = 0; i < n; i++)
{
    string name = Console.ReadLine();
    list.Add(name);
}
int[] indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
Swapper<string> swapper = new(list);
swapper.SwapItems(indexes[0], indexes[1]);
foreach(var item in list)
{
    Console.WriteLine($"{item.GetType()}: {item}");
}