﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCount
{
    public class CountMethod<T> where T : IComparable<T>
    {
        List<T> values = new List<T>();

        public CountMethod(List<T> values)
        {
            this.values = values;
        }

        public int countOfBiggerTs(T comparer)
        {
            int count = 0;
            foreach(T t in values)
            {
                if(t.CompareTo(comparer) > 0)
                {
                    count++;
                }
            }
            return count;
        }
    }
}
