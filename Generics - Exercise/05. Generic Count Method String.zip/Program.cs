﻿using GenericCount;

int n = int.Parse(Console.ReadLine());
List<string> list = new List<string>();
for(int i = 0; i < n; i++)
{
    string a = Console.ReadLine();
    list.Add(a);
}
string comparer = Console.ReadLine();
CountMethod<string> counter = new(list);
Console.WriteLine(counter.countOfBiggerTs(comparer));
