﻿using Tuple;

var line1 = Console.ReadLine().Split();
string name = line1[0] + " " + line1[1];
string country  = line1[2];
string city = line1[3];
Typle<string, string, string> tuple = new(name, country, city);
Console.WriteLine(tuple.Print());

var line2 = Console.ReadLine().Split();
string nameOfDrinker = line2[0];
int beers = int.Parse(line2[1]);
bool isDrunk = false;
if (line2[2] == "drunk") { isDrunk = true; }
Typle<string, int, bool> tuple1 = new(nameOfDrinker, beers, isDrunk);
Console.WriteLine(tuple1.Print());

var line3 = Console.ReadLine().Split();
string nameOfValue = line3[0];
double balance = double.Parse(line3[1]);
string bankName = line3[2];
Typle<string, double, string> typle = new(nameOfValue, balance, bankName);
Console.WriteLine(typle.Print());