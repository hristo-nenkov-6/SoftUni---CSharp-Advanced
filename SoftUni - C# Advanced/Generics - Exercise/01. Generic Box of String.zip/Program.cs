﻿using GenericBoxOfString;
    int n = int.Parse(Console.ReadLine());
    for(int i = 0; i < n; i++)
    {
        string x = Console.ReadLine();
        Box<string> box = new();
        box.ToString(x);
    }