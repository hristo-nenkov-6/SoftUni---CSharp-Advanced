﻿using GenericCount;

int n = int.Parse(Console.ReadLine());
List<double> list = new List<double>();
for(int i = 0; i < n; i++)
{
    double a = double.Parse(Console.ReadLine());
    list.Add(a);
}
double comparer = double.Parse(Console.ReadLine());
CountMethod<double> counter = new(list);
Console.WriteLine(counter.countOfBiggerTs(comparer));