﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swapper
{
    public class Swapper<T>
    {
        public Swapper(List<T> List)
        {
            this.list = List;
        }
        private List<T> list;
        public void SwapItems(int index1, int index2)
        {
            var t = list[index1];
            list[index1] = list[index2];
            list[index2] = t;
        }
    }
}
