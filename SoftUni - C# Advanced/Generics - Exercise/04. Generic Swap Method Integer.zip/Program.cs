﻿using Swapper;

int n = int.Parse(Console.ReadLine());
List<int> list = new List<int>();
for(int i = 0; i < n; i++)
{
    int name = int.Parse(Console.ReadLine());
    list.Add(name);
}
int[] indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
Swapper<int> swapper = new(list);
swapper.SwapItems(indexes[0], indexes[1]);
foreach(var item in list)
{
    Console.WriteLine($"{item.GetType()}: {item}");
}