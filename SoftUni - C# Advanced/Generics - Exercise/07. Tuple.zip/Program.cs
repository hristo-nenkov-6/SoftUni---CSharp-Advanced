﻿using Tuple;

var line1 = Console.ReadLine().Split();
string name = line1[0] + " " + line1[1];
string country  = line1[2];
Typle<string, string> tuple = new(name, country);
Console.WriteLine(tuple.Print());

var line2 = Console.ReadLine().Split();
string nameOfDrinker = line2[0];
int beers = int.Parse(line2[1]);
Typle<string, int> tuple1 = new(nameOfDrinker, beers);
Console.WriteLine(tuple1.Print());

var line3 = Console.ReadLine().Split();
int integer = int.Parse(line3[0]);
double doubleType = double.Parse(line3[1]);
Typle<int, double> tuple2 = new(integer, doubleType);
Console.WriteLine(tuple2.Print());