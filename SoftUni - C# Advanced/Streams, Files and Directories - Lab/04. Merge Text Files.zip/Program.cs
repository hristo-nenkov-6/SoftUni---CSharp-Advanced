﻿namespace WordCount
{
    public class WordCount
    {
        static void Main()
        {
            string wordPath = @"..\..\..\Files\words.txt";
            string textPath = @"..\..\..\Files\text.txt";
            string outputPath = @"..\..\..\Files\output.txt";
            CalculateWordCounts(wordPath, textPath, outputPath);
        }
        public static void CalculateWordCounts(string wordsFilePath, string
        textFilePath, string outputFilePath)
        {
            var dict = new Dictionary<string, int>();
            var words = new List<string>();

            using (var reader = new StreamReader(wordsFilePath))
            {
                string text = reader.ReadToEnd().ToLower();
                var splittedLine = text.Split() ;
                for (int i = 0; i < splittedLine.Length; i++)
                {
                    words.Add(splittedLine[i]);
                }
            }

            using (var reader = new StreamReader(textFilePath))
            {
                string text = reader.ReadToEnd().ToLower();
                String[] separators = { " ", ",", "-", ".", "!", "?", "..." };
                var splittedLine = text.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < words.Count; i++)
                {
                    for(int j = 0; j <  splittedLine.Length; j++)
                    {
                        string currWord = words[i];
                        if (splittedLine[j] == (currWord))
                        {
                            if (!dict.ContainsKey(currWord))
                            {
                                dict.Add(currWord, 1);
                            }
                            else
                            {
                                dict[currWord]++;
                            }
                        }
                    }
                }
            }

            using (var writer = new StreamWriter(outputFilePath))
            {
                foreach (var item in dict.OrderByDescending(x => x.Value))
                {
                    writer.WriteLine($"{item.Key} - {item.Value}");
                }
            }
        }
    }
}
