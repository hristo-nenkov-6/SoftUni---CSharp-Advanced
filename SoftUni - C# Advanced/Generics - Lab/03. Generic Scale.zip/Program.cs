﻿
namespace GenericScale
{
    public class StartUp
    {
        public static void Main()
        {
            EqualityScale<int> es = new(5, 6);
        }
        
    }
}