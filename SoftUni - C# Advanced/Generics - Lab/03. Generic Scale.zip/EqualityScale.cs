﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericScale
{
    public class EqualityScale<T> where T : IComparable<T>
    {
        public T Left {  get; set; }
        public T Right { get; set; }
        public EqualityScale(T left, T right)
        {
            this.Left = left;
            this.Right = right;
        }
        public bool AreEqual()
        {
            return Left.Equals(Right);
        }
        public T IsBigger()
        {
            if(Left.CompareTo(Right) > 0)
            {
                return Left;
            }
            else
            {
                return Right;
            }
        }
    }
}
