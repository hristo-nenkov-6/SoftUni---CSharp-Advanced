﻿namespace MergeFiles
{
    public class MergeFiles
    {
        static void Main()
        {
            var firstInputFilePath = @"..\..\..\Files\input1.txt";
            var secondInputFilePath = @"..\..\..\Files\input2.txt";
            var outputFilePath = @"..\..\..\Files\output.txt";
            MergeTextFiles(firstInputFilePath, secondInputFilePath,
           outputFilePath);
        }
        public static void MergeTextFiles(string firstInputFilePath, string
       secondInputFilePath, string outputFilePath)
        {
            var list1 = new Queue<string>();
            var list2 = new Queue<string>();
            var outQueue = new Queue<string>();

            using(var reader = new StreamReader(firstInputFilePath))
            {
                string line = string.Empty;
                while((line = reader.ReadLine()) != null)
                {
                    list1.Enqueue(line);
                }
            }

            using (var reader = new StreamReader(secondInputFilePath))
            {
                string line = string.Empty;
                while ((line = reader.ReadLine()) != null)
                {
                    list2.Enqueue(line);
                }
            }

            int sum = list1.Count + list2.Count;
            for (int i  = 0; i < sum; i++)
            {
                if(i % 2 == 0 && list1.Count > 0)
                {
                    outQueue.Enqueue(list1.Dequeue());
                }
                else if(i % 2 == 1 && list2.Count > 0)
                {

                    outQueue.Enqueue(list2.Dequeue());
                }
            }

            if(list1.Count != 0)
            {

                while (list1.Count > 0)
                {
                    outQueue.Enqueue(list1.Dequeue());
                }
            }
            else
            {
                while (list2.Count > 0)
                {
                    outQueue.Enqueue(list2.Dequeue());
                }
            }

            using(var writer = new StreamWriter(outputFilePath))
            {
                int count = outQueue.Count;
                for(int i = 0; i < count; i++)
                {
                    writer.WriteLine(outQueue.Dequeue());
                }
            }
        }
    }
}