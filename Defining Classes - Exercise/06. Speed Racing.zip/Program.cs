﻿using ConsoleApp1;

int n = int.Parse(Console.ReadLine());
List<Car> cars1 = new List<Car>();

for(int i = 0; i < n; i++)
{
    var cars = Console.ReadLine().Split();
    string model = cars[0];
    double fuelAmount = double.Parse(cars[1]);
    double fuelConsumption = double.Parse(cars[2]);

    Car car = new Car(model, fuelAmount, fuelConsumption, 0);
    cars1.Add(car);
}

string input = string.Empty;
while((input = Console.ReadLine()) != "End")
{
    string model = input.Split()[1];
    int distanceTravelled = int.Parse(input.Split()[2]);

    Car currentCar = cars1.Find(x => x.Model ==  model);
    currentCar.Drive(distanceTravelled);
}

foreach(Car car in cars1)
{
    Console.WriteLine($"{car.Model} {car.FuelAmount:f2} {car.TravelledDistance}");
}