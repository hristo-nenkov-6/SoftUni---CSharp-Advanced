﻿using System;

namespace DateModifier;

    public class StartUp
    {
        static void Main(string[] args)
        {
            string date1 = Console.ReadLine();
            string date2 = Console.ReadLine();

            int days = DateModifier.DifferenceInDays(date1, date2);
            Console.WriteLine(days);
        }
    }