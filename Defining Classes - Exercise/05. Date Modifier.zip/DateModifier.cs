﻿using System;

namespace DateModifier;

public static class DateModifier
{
    public static int DifferenceInDays(string start, string end)
    {
        DateTime startDate = DateTime.Parse(start);
        DateTime endDate = DateTime.Parse(end);

        var days = startDate - endDate;
        int intDays = Math.Abs(days.Days);
        return intDays;
    }
}
